package com.techm.telecom;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTelecomPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTelecomPortalApplication.class, args);
	}

}
