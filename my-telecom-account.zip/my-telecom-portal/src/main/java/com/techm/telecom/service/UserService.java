package com.techm.telecom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.techm.telecom.model.User;
import com.techm.telecom.model.account.MyAccount;
import com.techm.telecom.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	public List<User> getUserDetails() {
		return userRepository.findAll();
	}

	public User getUserByUserId(long id) {
		return userRepository.findById(id).get();
	}

	public List<User> saveUserList(List<User> users) {
		return userRepository.saveAll(users);
	}

	public User saveSingleUser(User user) {
		return userRepository.save(user);
	}
	
	public List<MyAccount> getMyAccountByMyPhone(String myPhone) {
		List<MyAccount> myAccounts= restTemplate.getForObject("http://localhost:8282/myPhone/"+myPhone, List.class);
		System.out.println("myAccounts: "+myAccounts);
		return myAccounts;
	}
}
